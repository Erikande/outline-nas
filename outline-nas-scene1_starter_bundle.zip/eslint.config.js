import globals from 'globals'

export default [
  {
    files: ["**/*.js", "**/*.ts"],
    languageOptions: { globals: { ...globals.node } },
    rules: {
      'no-unused-vars': 'warn',
      'no-undef': 'error'
    }
  }
]
