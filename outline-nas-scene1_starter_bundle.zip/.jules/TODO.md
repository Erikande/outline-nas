# Jules TODOs (Scene 2)

- Add CI job to deploy on tag (prod)
- Draft docker-compose with Caddy reverse proxy (Tailnet certs)
- Propose rclone backup job for Outline storage + DB dumps
- Propose separate compose for Obsidian vault sync (Syncthing)
- Add devcontainer for reproducible local setup
- Add secret scanning (gitleaks) in CI
